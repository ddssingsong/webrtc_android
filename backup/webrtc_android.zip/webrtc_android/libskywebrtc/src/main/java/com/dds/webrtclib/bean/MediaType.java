package com.dds.webrtclib.bean;

/**
 * Created by dds on 2019/5/3.
 * android_shuai@163.com
 */
public class MediaType {
    public final static int TYPE_AUDIO = 0;
    public final static int TYPE_VIDEO = 1;
    public final static int TYPE_MEETING = 2;

}
