package com.dds.webrtclib.callback;

/**
 * Created by dds on 2019/2/22.
 * android_shuai@163.com
 */
public interface ConnectCallback {

    void onSuccess();

    void onFailed();
}
